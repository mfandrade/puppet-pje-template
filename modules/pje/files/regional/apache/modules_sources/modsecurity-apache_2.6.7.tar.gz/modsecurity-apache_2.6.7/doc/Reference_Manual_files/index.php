/* generated javascript */
var skin = 'sourceforge';
var stylepath = '/apps/mediawiki/mod-security/skins';

/* MediaWiki:Common.js */
/* Any JavaScript here will be loaded for all users on every page load. */

/* MediaWiki:Sourceforge.js */
