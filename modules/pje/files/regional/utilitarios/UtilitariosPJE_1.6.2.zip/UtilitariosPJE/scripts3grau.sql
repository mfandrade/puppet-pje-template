UPDATE "core"."tb_parametro"
   SET "vl_variavel"='false',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'loginComCertificado');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='true',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'modoTesteCertificado');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='S',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'aplicacaoModoTeste');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#enderecoWSDLPublicaDiario',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'enderecoWSDLPublicaDiario');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#enderecoWSDLConsultaDiario',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'enderecoWSDLConsultaDiario');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#urlWebserviceBNDT',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'urlWebserviceBNDT');

------------------------------------------------------------------------------------------------------------------------------------

-- ATUALIZACAO DE PARAMETROS DE SUBIDA/DESCIDA

-- ATUALIZACAO DOS ENDERECOS DA INSTÂNCIA INFERIOR NOS PROCESSOS JÁ ENVIADOS

UPDATE client.tb_manifestacao_processual
SET ds_wdsl_origem_envio = '#urlAplicacao2grau/intercomunicacao?wsdl'
WHERE ds_wdsl_origem_envio <> '' and ds_wdsl_origem_envio is not null;

UPDATE client.tb_manifestacao_processual
SET ds_wdsl_origem_consulta = '#urlAplicacao2grau/ConsultaPJe?wsdl'
WHERE ds_wdsl_origem_consulta <> '' and ds_wdsl_origem_consulta is not null;

