UPDATE "core"."tb_parametro"
   SET "vl_variavel"='false',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'loginComCertificado');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='true',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'modoTesteCertificado');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='S',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'aplicacaoModoTeste');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#enderecoWSDLPublicaDiario',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'enderecoWSDLPublicaDiario');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#enderecoWSDLConsultaDiario',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'enderecoWSDLConsultaDiario');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#urlWebserviceBNDT',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'urlWebserviceBNDT');
------------------------------------------------------------------------------------------------------------------------------------

--PREENCHER COM AS INFORMACOES ESPECIFICAS DAS BASES DE BUGFIX DE CADA REGIONAL
-- 2grau
UPDATE client.tb_remessa_processo_host SET ds_url = '#enderecoFull2Grau', ds_url_homologacao = '#enderecoFull2Grau', ds_login = '#usuarioBanco2Grau', ds_senha = '#senhaBanco2GrauCriptografada' 
WHERE id_sessao_destino = 0;
-- 1grau
UPDATE client.tb_remessa_processo_host SET ds_url = '#enderecoFull1Grau', ds_url_homologacao = '#enderecoFull1Grau', ds_login = '#usuarioBanco1Grau', ds_senha = '#senhaBanco1GrauCriptografada' 
WHERE id_sessao_destino = 4;
------------------------------------------------------------------------------------------------------------------------------------

-- ATUALIZACAO DE PARAMETROS DE SUBIDA/DESCIDA

-- ATUALIZACAO DOS ENDERECOS DA INSTÂNCIA INFERIOR NOS PROCESSOS JÁ ENVIADOS

UPDATE client.tb_manifestacao_processual
SET ds_wdsl_origem_envio = '#urlAplicacao1grau/intercomunicacao?wsdl'
WHERE ds_wdsl_origem_envio <> '' and ds_wdsl_origem_envio is not null;

UPDATE client.tb_manifestacao_processual
SET ds_wdsl_origem_consulta = '#urlAplicacao1grau/ConsultaPJe?wsdl'
WHERE ds_wdsl_origem_consulta <> '' and ds_wdsl_origem_consulta is not null;

-- ATUALIZACAO DE PARAMETROS DE SUBIDA/DESCIDA

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao2grau/intercomunicacao?wsdl'
WHERE nm_variavel ilike 'urlWsdlAplicacaoOrigem';

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao2grau/ConsultaPJe?wsdl'
WHERE nm_variavel ilike 'urlWsdlAplicacaoOrigemConsulta';

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao3grau/intercomunicacao?wsdl'
WHERE nm_variavel ilike 'urlWsdlEnvioInstanciaSuperior';

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao3grau/ConsultaPJe?wsdl'
WHERE nm_variavel ilike 'urlWsdlPJeInstanciaSuperior';

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao1grau/intercomunicacao?wsdl'
WHERE nm_variavel ilike 'urlWsdlEnvioInstanciaInferior';

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao1grau/ConsultaPJe?wsdl'
WHERE nm_variavel ilike 'urlWsdlPJeInstanciaInferior';
