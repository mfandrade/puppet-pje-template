UPDATE "core"."tb_parametro"
   SET "vl_variavel"='false',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'loginComCertificado');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='true',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'modoTesteCertificado');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='S',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'aplicacaoModoTeste');

-- Parâmetro para inibir necessidade de uso do certificado ao usar o AUD.
-- Os dois scripts a seguir servem como um "INSERT or UPDATE"
UPDATE "core"."tb_parametro"
   SET "vl_variavel"='true',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel='desabilitarAutenticacaoAutorizacaoAUD');
INSERT INTO core.tb_parametro (nm_variavel, ds_variavel, vl_variavel, dt_atualizacao, in_sistema, in_ativo)
SELECT 'desabilitarAutenticacaoAutorizacaoAUD', 'desabilitarAutenticacaoAutorizacaoAUD', 'true', now(), 'N', 'S'
WHERE NOT EXISTS (SELECT 1 FROM core.tb_parametro WHERE id_parametro=(SELECT id_parametro FROM core.tb_parametro WHERE nm_variavel ilike 'desabilitarAutenticacaoAutorizacaoAUD'));

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#enderecoWSDLPublicaDiario',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'enderecoWSDLPublicaDiario');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#enderecoWSDLConsultaDiario',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'enderecoWSDLConsultaDiario');

UPDATE "core"."tb_parametro"
   SET "vl_variavel"='#urlWebserviceBNDT',
        "dt_atualizacao"=now()
WHERE id_parametro=(SELECT id_parametro FROM "core"."tb_parametro" WHERE nm_variavel ilike 'urlWebserviceBNDT');
------------------------------------------------------------------------------------------------------------------------------------

--PREENCHER COM AS INFORMACOES ESPECIFICAS DAS BASES DE BUGFIX DE CADA REGIONAL
-- 2grau
UPDATE client.tb_remessa_processo_host SET ds_url = '#enderecoFull2Grau', ds_url_homologacao = '#enderecoFull2Grau', ds_login = '#usuarioBanco2Grau', ds_senha = '#senhaBanco2GrauCriptografada' 
WHERE id_sessao_destino = 0;
-- 1grau
UPDATE client.tb_remessa_processo_host SET ds_url = '#enderecoFull1Grau', ds_url_homologacao = '#enderecoFull1Grau', ds_login = '#usuarioBanco1Grau', ds_senha = '#senhaBanco1GrauCriptografada' 
WHERE id_sessao_destino = 4;
------------------------------------------------------------------------------------------------------------------------------------

-- ATUALIZACAO DE PARAMETROS DE SUBIDA/DESCIDA

-- ATUALIZACAO DOS ENDERECOS DA INSTÂNCIA SUPERIOR NOS PROCESSOS JÁ DEVOLVIDOS

UPDATE client.tb_manifestacao_processual
SET ds_wdsl_origem_envio = '#urlAplicacao2grau/intercomunicacao?wsdl'
WHERE ds_wdsl_origem_envio <> '' and ds_wdsl_origem_envio is not null;

UPDATE client.tb_manifestacao_processual
SET ds_wdsl_origem_consulta = '#urlAplicacao2grau/ConsultaPJe?wsdl'
WHERE ds_wdsl_origem_consulta <> '' and ds_wdsl_origem_consulta is not null;

-- ATUALIZACAO DE PARAMETROS DE SUBIDA

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao1grau/intercomunicacao?wsdl'
WHERE nm_variavel ilike 'urlWsdlAplicacaoOrigem';

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao1grau/ConsultaPJe?wsdl'
WHERE nm_variavel ilike 'urlWsdlAplicacaoOrigemConsulta';

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao2grau/ConsultaPJe?wsdl'
WHERE nm_variavel ilike 'urlWsdlPJeInstanciaSuperior';

UPDATE core.tb_parametro
SET vl_variavel = '#urlAplicacao2grau/intercomunicacao?wsdl'
WHERE nm_variavel ilike 'urlWsdlEnvioInstanciaSuperior';
